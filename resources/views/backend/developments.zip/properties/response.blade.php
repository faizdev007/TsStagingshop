@extends('backend.properties.template')

@section('property-content')

@if(!empty($enquiry))

    <div class="x_content">
        <div class="x_panel pw-inner-tabs">
            @include('backend.enquiries.enquiry-details')
        </div>

        <div class="x_panel pw-inner-tabs">
            <div class="x_title">
                <h2>Reply Message</h2>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div>
                    <div class="control-form">
                        @php if(!empty($enquiry->reply_message)){ @endphp
                            <p>{!!$enquiry->reply_message!!}</p>
                        @php }else{ @endphp
                            {!! Form::open(['action'=> ['Backend\EnquiriesController@update', $enquiry->id], 'method' => 'POST']) !!}
                                @csrf
                                @method('PUT')
                                {{Form::textarea('reply_message', '', ['id'=> 'reply_message', 'class'=> 'style-1 description', 'style'=>'width:100%', 'placeholder'=>'Please enter...'])}}
                                <div class="form-group sticky-buttons">
                                    <button type="submit" class="btn btn-primary">Reply</button>
                                    <a href="{{admin_url('properties/'.$property->id.'/leads')}}" class="btn btn-default btn-spacing">Cancel and Return</a>
                                </div>
                            {!! Form::close() !!}
                        @php } @endphp
                    </div>
                </div>
            </div>
        </div>
    </div>
@else
    <div class="no-data">
        No data found.
    </div>
@endif

@endsection
