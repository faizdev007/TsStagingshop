@extends('backend.properties.template')

@section('property-content')
<div>

    <div class="row">
        <div class="col-md-6 col-sm-6 col-xs-12">
            <table class="table table-striped ">
                <thead>
                    <tr>
                        <th colspan="3">Past 30 days</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td width="50%">Views</td>
                        <td width="50%" class="text-center">{{ $property_30days_view_total }}</td>
                    </tr>
                    <tr>
                        <td>Enquiries</td>
                        <td class="text-center">{{ $total_past_30days }}</td>
                    </tr>
                    <tr>
                        <td class="ref-link">
                            Search Views
                            @if(count($property_search_30days_stats))
                            - <a href="#" data-toggle="modal" data-target="#search-url-30days">See URLs</a>
                            @endif
                        </td>
                        <td class="text-center">{{ $property_30days_search_total }}</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="col-md-6 col-sm-6 col-xs-12">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th colspan="3">All-time</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td width="50%">Views</td>
                        <td width="50%" class="text-center">{{ $property_view_total }}</td>
                    </tr>
                    <tr>
                        <td>Enquiries</td>
                        <td class="text-center">
                            {{ count($property->propertyEnquiries) }}
                        </td>
                    </tr>
                    <tr>
                        <td class="ref-link">
                            Search Views
                            @if(count($property_search_stats))
                            - <a href="#" data-toggle="modal" data-target="#search-url">See URLs</a>
                            @endif
                        </td>
                        <td class="text-center">
                            {{ $property_search_total  }}
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="search-url" class="modal fade " role="dialog">
    <div class="modal-dialog modal-md">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Search URLs - All-time</h4>
            </div>
            <div class="modal-body">
                <div class="">
                    @if(count($property_search_stats))
                        @foreach( $property_search_stats as $stat )
                            <div>({{ $stat->total }}) <a href="{{ url($stat->data) }}" target="_blank">{{ url($stat->data) }}</a> </div>
                        @endforeach
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="search-url-30days" class="modal fade " role="dialog">
    <div class="modal-dialog modal-md">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Search URLs - Past 30 days</h4>
            </div>
            <div class="modal-body">
                <div class="">
                    @if(count($property_search_30days_stats))
                        @foreach( $property_search_30days_stats as $stat )
                            <div>({{ $stat->total }}) <a href="{{ url($stat->data) }}" target="_blank">{{ url($stat->data) }}</a> </div>
                        @endforeach
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<div class="form-group sticky-buttons">
    @include('backend.properties.sticky-buttons')
</div>
@endsection
