@extends('backend.layouts.master')

@section('admin-content')

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel pw">
            <div class="x_title">
                <h2>Property Search</h2>
                <ul class="nav navbar-right panel_toolbox">
                  <li class="top-button"><a href="{{admin_url('properties/create')}}" class="btn btn-small btn-primary">Create Property</a></li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">

                <div class="search-form-style-1">
                    @include('backend.properties.search-form')
                </div>

                <div class="table-responsive pw-table">

                    @if(count($properties))
                    {!! $properties->appends(\Input::except('page'))->render() !!}
                    <table class="table table-striped jambo_table bulk_action table-bordered-">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Ref.</th>
                                <th>Title</th>
                                <th>Price</th>
                                @if(setting('branches_option') == 1 && Auth::user()->role_id <= '2')
                                    <th>Branch</th>
                                @endif
                                <th>Status</th>
                                <th>Date Added</th>
                                <th class="text-center">Featured?</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($properties as $property)
                            <tr>
                                <td><a href="{{admin_url('properties/'.$property->id.'/edit')}}"><img src="{{ $property->primary_photo }}" alt="{{$property->property_name}}" class="pw-thumbnail-75"></a></td>
                                <td class="ref-link"><a href="{{admin_url('properties/'.$property->id.'/edit')}}">{{$property->ref}}</a></td>
                                <td>{{$property->search_headline}}</td>
                                <td>{!!$property->display_price!!}</td>
                                @if(setting('branches_option') == 1 && Auth::user()->role_id <= '2')
                                    <td>
                                        @if($property->branch)
                                            {{ $property->branch->branch_name }}
                                        @else
                                            N/A
                                        @endif
                                    </td>
                                @endif
                                <td>{{$property->state_display}}</td>
                                <td>{{$property->display_date}}</td>
                                <td class="text-center">
                                    @if($property->is_featured)
                                        <i class="fa fa-check"></i>
                                    @endif
                                </td>
                                <td class="text-center table-active-btn">

                                    <a href="{{admin_url('properties/'.$property->id.'/edit')}}" class="btn btn-small btn-primary">Edit</a>

                                    @if($property->status == 1)
                                        | <a href="{{admin_url('properties/'.$property->id.'/reactive')}}" class="confirm-action btn btn-small btn-info" title="reactivate this property">Reactivate</a>

                                        @if(  Auth::user()->role_id == '1' )
                                        | <a href="{{admin_url('properties/'.$property->id.'/delete')}}" class="confirm-action btn btn-small btn-danger" title="permanently delete this property">Delete</a>
                                        @endif

                                    @endif

                                    @if($property->status == 0)
                                        | <a href="{{ url($property->url) }}" target="_blank" class="btn btn-small btn-info">View</a>
                                    @endif

                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    {!! $properties->appends(\Input::except('page'))->render() !!}
                    @else
                        <div class="no-data">
                            No data found.
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@push('headerscripts')
<meta name="csrf-token" content="{{ csrf_token() }}">
@endpush

@push('footerscripts')
<script src="{{url('assets/admin/build/vendors/jquery/jquery.ui.touch-punch.min.js')}}"></script>
<script src="{{url('assets/admin/build/vendors/jquery/jquery.formatCurrency-1.4.0.min.js')}}"></script>
<script src="{{url('assets/admin/build/js/price-range.js')}}"></script>
<script src="{{url('assets/admin/build/js/pw-select2-ajax.js')}}"></script>
@endpush
