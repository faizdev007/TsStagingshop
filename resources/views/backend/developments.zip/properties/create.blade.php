@extends('backend.layouts.master')

@section('admin-content')

{!! Form::open(['action'=> ['Backend\PropertiesController@store'], 'method' => 'POST']) !!}
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel pw">
            <div class="x_title">
                <h2><br/></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <p class="text-muted font-13 m-b-30"><br/></p>
                <div class="x_panel pw-inner-tabs">
                    <div class="x_title">
                        <h2>Property Fields</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-down"></i></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content pw-open">

                        <div class="xpw-fields">

                            <input type="hidden" name="is_featured" value="0">
                            <input type="hidden" name="country" value="{{ !empty(settings('overseas_country')) ? settings('overseas_country') : 'United Kingdom' }}">

                            <div class="row">

                                <div class="col-md-4">
                                    <div class="control-form">
                                        <label>Status: {!! required_label() !!}</label>
                                        {{ Form::select('status', p_states(), 0, [ 'id' => 'id-status', 'class' => 'form-control select-pw']) }}
                                    </div>
                                </div>

                                @if(setting('sale_rent') == 'sale_rent')
                                    <div class="col-md-4">
                                        <div class="control-form">
                                            <label for="fullname">Field Type: {!! required_label() !!}</label>
                                            {{ Form::select('is_rental', p_fieldTypes(), '', ['id'=>'id-mode', 'class' => 'form-control select-pw mode-attr', 'data-category'=>'.p-category']) }}
                                        </div>
                                    </div>
                                @elseif(setting('sale_rent') == 'sale')
                                    <input type="hidden" name="is_rental" value="0">
                                @else
                                    <input type="hidden" name="is_rental" value="1">
                                @endif

                                @if(0)
                                <div class="col-md-4">
                                    <div class="control-form p-category-field">
                                        <label>Subtype: {!! required_label() !!}</label>
                                        {{ Form::select('category_type', p_category(), '', ['class' => 'form-control select-pw p-category']) }}
                                    </div>
                                </div>@endif

                                <div class="col-md-4">
                                    <div class="control-form p-category-field">
                                        <label>Community:</label>
                                        {{ Form::select('community_id', p_communities('Please select...'), '', ['class' => 'form-control select-pw']) }}
                                    </div>
                                </div>

                                @if(  Auth::user()->role_id == '1' )
                                <div class="col-md-4">
                                    <div class="control-form">
                                        <label>Agent: {!! required_label() !!}</label>
                                        {{ Form::select('user_id', [''=>'Please Select'] , '', [ 'readonly', 'class' => 'form-control select-pw-ajax-agent']) }}
                                    </div>
                                </div>
                                @else
                                    <input type="hidden" name="user_id" value="{{ Auth::user()->id }}">
                                @endif

                               
                                <div class="col-md-4">
                                    <div class="control-form">
                                        <label>Property Type: {!! required_label() !!}</label>
                                        {{ Form::select('property_type_id', prepare_dropdown_ptype($propertyTypes), '', ['class' => 'form-control select-pw']) }}
                                    </div>
                                </div>

                                @if(setting('branches_option') == 1 && Auth::user()->role_id <= '2')
                                    <div class="col-md-3">
                                        <div class="control-form">
                                            <label>Branch</label>
                                            <select id="id-mode" class="form-control select-pw" name="branch_id" data-placeholder="Optional....">
                                                <option></option>
                                                @foreach($branches as $branch)
                                                    <option value="{{ $branch->branch_id }}">{{ $branch->branch_name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    @else
                                        @if(setting('branches_option') == 1)
                                            <input type="hidden" name="branch_id" value="{{ Auth::user()->branch_id }}">
                                        @endif
                                @endif

                            </div>

                        </div>

                    </div>
                </div>


                <!-- <div class="x_panel pw-inner-tabs">
                    <div class="x_title">
                        <h2>Property Type</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="xpw-fields">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="control-form">
                                        <select id="li-feature" class="select-pw w-100 type-select" name="property_type_ids[]" data-placeholder="Please select..." multiple>
                                            <?php
                                                $ptypeArray = prepare_dropdown_ptype($propertyTypes);
                                                foreach($ptypeArray as $id => $propertyType){
                                                ?>
                                                    <option value="<?=$id?>" ><?=$propertyType?></option>
                                                <?php
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
 -->
                <div class="x_panel pw-inner-tabs">
                    <div class="x_title">
                        <h2>General Info</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>

                    <div class="x_content">
                        <div class="xpw-fields">
                            <div class="row">

                                <div class="col-md-3">
                                    <div class="control-form">
                                        <label>Price({!! setting('currency_symbol') !!}): {!! required_label() !!}</label>
                                        {{Form::text('price', '', ['id'=> 'id-price', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="control-form">
                                        <label>Number of bedrooms: {!! required_label() !!}</label>
                                        {{ Form::select('beds', p_beds(), '', ['class' => 'form-control select-pw']) }}
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="control-form">
                                        <label>Number of bathrooms:</label>
                                        {{ Form::select('baths', p_baths(), '', ['class' => 'form-control select-pw']) }}
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<div class="form-group sticky-buttons">
    <button type="submit" class="btn btn-large btn-primary" name="action" >Create</button>
    <a href="{{admin_url('properties')}}" class="btn btn-default btn-spacing">Cancel <span>and Return<span></a>
</div>

{!! Form::close() !!}

@endsection

@push('headerscripts')
<meta name="csrf-token" content="{{ csrf_token() }}">
@endpush

@push('footerscripts')
<script src="{{url('assets/admin/build/js/pw-select2-ajax.js')}}"></script>
<script src="{{url('assets/admin/build/js/page-detail.js')}}"></script>
@endpush
