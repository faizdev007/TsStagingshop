<div class="search-collapse">
    <a href="#" data-toggle="collapse" data-target=".title-search" class="cta-collapse"><i class="fa fa-search"></i> Search </a>
</div>

{!! Form::open(['action'=> ['Backend\PropertiesController@index', ''], 'method' => 'GET', 'class' => 'title-search']) !!}
<ul class="sf-field">
    @if(setting('sale_rent') == 'sale_rent')
    <li>
        {{ Form::select('for', p_fieldTypesSearch('Type'), Input::get('for'), ['id'=>'id-mode', 'class' => 'form-control select-pw price-range-search']) }}
    </li>
    @elseif(setting('sale_rent') == 'sale')
        <input name="for" type="hidden" value="sale" class="price-range-search">
    @else
        <input name="for" type="hidden" value="rent" class="price-range-search">
    @endif
    <li>
        {{ Form::select('in', [ Input::get('in') => (Input::get('in')?urldecode(Input::get('in')):'Location' ) ], '', ['id'=>'id-location', 'class' => 'form-control select-pw-ajax-locations']) }}
    </li>
    <li>
        @if(0)
        {{ Form::select('property-type-ids[]', prepare_dropdown_ptype($propertyTypes,'Property'), Input::get('property_type_id'), ['id'=>'id-type', 'class' => 'form-control select-pw']) }}
        @endif
        <select id="li-feature-search" class="select-pw w-100 type-select" name="property-type-ids[]">
            <?php
                $selectedType = Input::get('property-type-ids');
                $selectedTypeVal = (is_array($selectedType) && !empty($selectedType[0])) ? $selectedType[0] : '';
                $ptypeArray = prepare_dropdown_ptype($propertyTypes, 'Property Type');
                foreach($ptypeArray as $id => $propertyType){
                ?>
                    <option value="<?=$id?>" {{ ($selectedTypeVal == $id) ? 'selected' : '' }} ><?=$propertyType?></option>
                <?php
                }
            ?>
        </select>
    </li>
    <li>
        <?php
          $price_range = Input::get('price_range');
          if(!empty($price_range)){
            $price_range_array = explode('-', $price_range);
            $minsel = $price_range_array[0];
            $maxsel = $price_range_array[1];
            $pvalue = $minsel."-".$maxsel;
          }else{
            $minsel = min_price();
            $maxsel = max_price();
            $pvalue = "";
            $price_range = "";
          }
        ?>
        <div id="price-range-search" class="price-slider-attr">
          <!--<label>Price Range</label>-->
          <div class="price-range-container">
            <div class="pr-wrap">
              <input type="hidden" class="price-range-input" name="price_range" value="<?=$price_range?>">
              <div class="price-slider" data-minsel="<?=$minsel?>" data-maxsel="<?=$maxsel?>"></div>
              <div class="price-indicator">
                <span class="price-label">Price Range:</span>
                <span class="min-price-slider slider-min formatPrice"></span> - <span class="max-price-slider slider-max formatPrice"></span>
              </div>
            </div>
          </div>
        </div>
    </li>

    <li>
        {{ Form::select('minbeds', p_beds('Min Beds'), Input::get('minbeds'), ['id'=>'id-minbeds', 'class' => 'form-control select-pw ']) }}
    </li>
    <li>
        {{Form::text('ref', Input::get('ref') ,['id'=> 'id-ref', 'class'=> 'form-control', 'placeholder'=>'Reference'])}}
    </li>
    <li>
        {{ Form::select('is_featured', [''=>'Featured', '1'=>'Yes', '2'=>'No'],  Input::get('is_featured'), ['id'=>'id-featured', 'class' => 'form-control select-pw']) }}
    </li>
    <li>
        {{ Form::select('status', p_states_search('Status'),  Input::get('status'), ['id'=>'id-status', 'class' => 'form-control select-pw']) }}
    </li>

    <li>
        {{ Form::select('is-brown-harris-stevens', [''=>'Is BHS?','yes'=>'Yes'], Input::get('is-brown-harris-stevens'), ['id'=>'id-isBHS', 'class' => 'form-control select-pw']) }}
    </li>

</ul>
<div class="clearfix"></div>

<ul class="sf-field sf-action">
    <li>
        <div class="pw-search-btn">
            <div class="psb-col">
                <button type="submit" name="search" value="yes" class="btn btn-small btn-primary pw-search-btn">Search</button>
            </div>
            <div class="psb-col">
                <a href="{{ admin_url('properties') }}" class="btn btn-small btn-default pw-search-btn">Clear <span>Search</span></a>
            </div>
        </div>
    </li>
</ul>
<div class="clearfix"></div>
{!! Form::close() !!}
