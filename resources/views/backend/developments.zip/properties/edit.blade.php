@extends('backend.properties.template')

@section('property-content')

{!! Form::open(['action'=> ['Backend\PropertiesController@update', $property->id], 'method' => 'POST']) !!}
<div class="x_panel pw-inner-tabs">
    <div class="x_title">
        <h2>Property Settings</h2>
        <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-down"></i></a>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>
    <div class="x_content pw-open">
        <div class="xpw-fields">
            <div class="row">
                <div class="@if(setting('sale_rent') !== 'sale_rent') col-md-4 @else col-md-4 @endif">
                    <div class="control-form">
                        <label>Status: {!! required_label() !!}</label>
                        {{ Form::select('status', p_states(), $property->status, [ 'id' => 'id-status', 'class' => 'form-control select-pw']) }}
                    </div>
                </div>

                @if(setting('sale_rent') == 'sale_rent')
                    <div class="col-md-4">
                        <div class="control-form">
                            <label>Field Type: {!! required_label() !!}</label>
                            {{ Form::select('is_rental', p_fieldTypes(), $property->is_rental, ['id'=>'id-mode', 'class' => 'form-control select-pw mode-attr', 'data-category'=>'.p-category']) }}
                        </div>
                    </div>
                @elseif(setting('sale_rent') == 'sale')
                    <input type="hidden" name="is_rental" value="0">
                @else
                    <input type="hidden" name="is_rental" value="1">
                @endif

                @if(0)
                <div class="col-md-4">
                    <div class="control-form p-category-field">
                        <label>Subtype: {!! required_label() !!}</label>
                        {{ Form::select('category_type', p_category(), $property->category_type, ['class' => 'form-control select-pw p-category', 'data-val'=>$property->category_type]) }}
                    </div>
                </div>@endif

                <div class="col-md-4">
                    <div class="control-form p-category-field">
                        <label>Community:</label>
                        {{ Form::select('community_id', p_communities(), $property->community_id, ['class' => 'form-control select-pw']) }}
                    </div>
                </div>

                @if(  Auth::user()->role_id == '3' )
                  {{Form::hidden('user_id', $property->user_id ,['readonly'])}}
                  {{Form::hidden('is_featured',$property->is_featured ,['readonly'])}}
                @else
                  <div class="@if(setting('sale_rent') !== 'sale_rent') col-md-4 @else col-md-4 @endif">
                      <div class="control-form">
                          <label>Agent: {!! required_label() !!}</label>
                          {{ Form::select('user_id', $agentSelected, $property->user_id, [ 'readonly', 'class' => 'form-control select-pw-ajax-agent']) }}
                      </div>
                  </div>
                  <div class="@if(setting('sale_rent') !== 'sale_rent') col-md-4 @else col-md-4 @endif">
                      <div class="control-form">
                          <label>Featured:</label>
                          {{ Form::select('is_featured', ['0' => 'No', '1' => 'Yes'], $property->is_featured, ['class' => 'form-control select-pw']) }}
                      </div>
                  </div>
                @endif

                @if(setting('branches_option') == 1)
                    <div class="col-md-6">
                        <div class="control-form">
                            <label>Branch</label>
                            <select id="id-mode" class="form-control select-pw" name="branch_id" data-placeholder="Optional....">
                                <option></option>
                                @foreach($branches as $branch)
                                    @if($property->branch)
                                        <option @if($branch->branch_id == $property->branch->branch_id) selected="selected" @endif value="{{ $branch->branch_id }}">{{ $branch->branch_name }}</option>
                                    @else
                                        <option value="{{ $branch->branch_id }}">{{ $branch->branch_name }}</option>
                                    @endif
                                @endforeach
                            </select>
                        </div>
                    </div>
                @endif

            </div>
        </div>

    </div>
</div>
<!-- 
<div class="x_panel pw-inner-tabs">
    <div class="x_title">
        <h2>Property Type</h2>
        <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>
    <div class="x_content">
        <div class="xpw-fields">
            <div class="row">
                <div class="col-md-12">
                    <div class="control-form">

                        <select id="li-feature" class="select-pw w-100 type-select" name="property_type_ids[]" data-placeholder="Please select..." multiple>
                            <?php
                                $ptypeArraySelected = !empty($property->property_type_ids) ? explode(',',$property->property_type_ids) : [];
                                $ptypeArray = prepare_dropdown_ptype($propertyTypes);
                                foreach($ptypeArray as $id => $propertyType){
                                    if(!empty($id)){
                                ?>
                                    <option value="<?=$id?>" {{ in_array($id, $ptypeArraySelected) ? 'selected' : '' }} ><?=$propertyType?></option>
                                <?php
                                } }
                            ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
 -->
<div class="x_panel pw-inner-tabs">
    <div class="x_title">
        <h2>Feed Export</h2>
        <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>
    <div class="x_content">
        <div class="xpw-fields">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-check">
                        {{ Form::checkbox('export_bhs', '1', $property->export_bhs, ['class'=>'form-check-input', 'id'=>'export_bhs']) }}
                        <label class="form-check-label" for="export_bhs">
                            Export to Brown Harris Stevens feed?
                        </label>
                        <small><a href="{{ route('bhs_feed') }}" target="_blank">(View feed)</a></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="x_panel pw-inner-tabs">
    <div class="x_title">
        <h2>General Info</h2>
        <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>

    <div class="x_content">

        <div class="xpw-fields">
            <div class="row">
                <div class="col-md-3">
                    <div class="control-form">
                        <label>Property Name:</label>
                        {{Form::text('name', $property->name ,['id'=> 'id-name', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="control-form">
                        <label>Price qualifier:</label>
                        {{ Form::select('price_qualifier', p_priceQualifiers(), $property->price_qualifier, ['class' => 'form-control select-pw']) }}
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="control-form">
                        <label>Price({!! setting('currency_symbol') !!}): {!! required_label() !!}</label>
                        {{Form::text('price', $property->price, ['id'=> 'id-price', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="control-form">
                        <label>Minimum Price ({!! setting('currency_symbol') !!}):</label>
                        {{Form::text('price_min', $property->price_min, ['id'=> 'id-price_min', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="control-form">
                        <label>Maximum Price ({!! setting('currency_symbol') !!}):</label>
                        {{Form::text('price_max', $property->price_max, ['id'=> 'id-price_max', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                    </div>
                </div>

                <div class="col-md-3" style="height: 79px;">
                    <div class="control-form for-rent">
                        <label>Rent Period:</label>
                        {{ Form::select('rent_period', p_rentPeriod(), $property->rent_period, ['class' => 'form-control select-pw']) }}
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="control-form">
                        <label>Property Status:</label>
                        {{ Form::select('property_status', p_statuses(), $property->property_status, ['id'=> 'id-property-status', 'class' => 'form-control select-pw']) }}
                    </div>
                </div>
            
                <div class="col-md-3">
                    <div class="control-form">
                        <label>Property Type: {!! required_label() !!}</label>
                        {{ Form::select('property_type_id', prepare_dropdown_ptype($propertyTypes), $property->property_type_id, ['class' => 'form-control select-pw']) }}
                    </div>
                </div>
               

                <div class="col-md-3">
                    <div class="control-form">
                        <label>Number of bedrooms: {!! required_label() !!}</label>
                        {{ Form::select('beds', p_beds(), $property->beds, ['class' => 'form-control select-pw']) }}
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="control-form">
                        <label>Number of bathrooms:</label>
                        {{ Form::select('baths', p_baths(), $property->baths, ['class' => 'form-control select-pw']) }}
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="control-form">
                        <label>Land Size ({{$property->AreaUnit}}):</label>
                        {{Form::text('land_area', $property->land_area ,['id'=> 'id-land_area', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="control-form">
                        <label>Area ({{$property->AreaUnit}}):</label>
                        {{Form::text('internal_area', $property->internal_area ,['id'=> 'id-internal_area', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="control-form">
                        <label>YouTube® ID (11-digit code):
                            @if(!empty($property->youtube_id))
                            <a href="#" class="link-1" data-toggle="modal" data-target="#myModal">View sample video</a>@endif
                        </label>
                        <div class="input-group">
							<div class="input-group-addon">https://youtube.com/watch?v=</div>
                            {{Form::text('youtube_id', $property->youtube_id ,['id'=> 'id-youtube_id', 'class'=> 'form-control', 'placeholder'=>'Please enter...', 'maxlength' => 11])}}
						</div>
                    </div>

                    @if(!empty($property->youtube_id))
                    <!-- Modal -->
                    <div id="myModal" class="modal fade " role="dialog">
                        <div class="modal-dialog modal-lg">
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Video</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="video-display">
                                        <iframe src="https://www.youtube.com/embed/{{ $property->youtube_id }}" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif

                </div>
            </div>
        </div>

    </div>
</div>

@if(setting('new_developments') && $property->is_development == 'y')
    <div class="x_panel pw-inner-tabs">
        <div class="x_title">
            <h2>Development Information</h2>
            <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                </li>
            </ul>
            <div class="clearfix"></div>
        </div>

        <div class="x_content">

            <div class="xpw-fields">
                <div class="row">
                    <div class="col-md-4">
                        <div class="control-form">
                            <label>Development Name</label>
                            @if($property->development)
                                {{Form::text('development_title', $property->development->development_title ,['id'=> 'id-name', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                            @else
                                {{Form::text('development_title', '' ,['id'=> 'id-name', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                            @endif
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="control-form">
                            <label>Development Heading</label>
                            @if($property->development)
                                {{Form::text('development_heading', $property->development->development_heading ,['id'=> 'id-name', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                            @else
                                {{Form::text('development_heading', '' ,['id'=> 'id-name', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                            @endif
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="control-form">
                            <label>Development Sub Heading</label>
                            @if($property->development)
                                {{Form::text('development_subheading', $property->development->development_subheading ,['id'=> 'id-name', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                            @else
                                {{Form::text('development_subheading', '' ,['id'=> 'id-name', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                            @endif
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="control-form">
                            <label>Development Completion Date</label>
                            <input name="completion_date" type="text" class="form-control datepicker" value="@if($property->development) {{ $property->development->completion_date }} @endif" placeholder="Choose a date">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="control-form">
                            <label>Developer</label>
                            @if($property->development)
                                {{Form::text('development_developer', $property->development->development_developer ,['id'=> 'id-name', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                            @else
                                {{Form::text('development_developer', '' ,['id'=> 'id-name', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                            @endif
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="control-form">
                            <label>Status</label>
                            @if($property->development)
                                {{Form::text('development_status', $property->development->development_status ,['id'=> 'id-name', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                            @else
                                {{Form::text('development_status', '' ,['id'=> 'id-name', 'class'=> 'form-control', 'placeholder'=>'Please enter...'])}}
                            @endif
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="control-form">
                            <label>Construction Start Date</label>
                            <input name="development_construction_start" type="text" class="form-control datepicker" value="@if($property->development) {{ $property->development->development_construction_start }} @endif" placeholder="Choose a date">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="control-form">
                            <label>Price From ({!! setting('currency_symbol') !!})</label>
                            <input name="development_price_from" type="text" class="form-control" value="@if($property->price) {{ $property->price }} @elseif($property->development) {{ $property->development->development_price_from }} @endif" placeholder="Please enter">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="control-form">
                            <label>Price To ({!! setting('currency_symbol') !!})</label>
                            <input name="development_price_to" type="text" class="form-control" value="@if($property->development) {{ $property->development->development_price_to }} @endif" placeholder="Please enter">
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endif

<div class="x_panel pw-inner-tabs">
    <div class="x_title">
        <h2>Key Features</h2>
        <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>
    <div class="x_content">
        <div class="xpw-fields">
            <div class="row">
                <div class="col-md-12">
                    {{Form::textarea('add_info', $property->add_info ,['id'=> 'id-add_info', 'class'=> 'tagEditor-style-1 style-1', 'placeholder'=>'Please enter...'])}}
                </div>
            </div>
        </div>
    </div>
</div>

<div class="x_panel pw-inner-tabs">
    <div class="x_title">
        <h2>Amenities</h2>
        <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>
    <div class="x_content">
        <div class="xpw-fields">
            <div class="row">
                <div class="col-md-12">
                    {{Form::textarea('add_amenities', $property->add_amenities ,['id'=> 'id-add_amenities', 'class'=> 'tagEditor-style-1 style-1', 'placeholder'=>'Please enter...'])}}
                </div>
            </div>
        </div>
    </div>
</div>


<div class="x_panel pw-inner-tabs">
    <div class="x_title">
        <h2>Description {!! required_label() !!}</h2>
        <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>
    <div class="x_content">
        <div class="xpw-fields">
            <div class="row">
                <div class="col-md-12">
                    {{Form::textarea('description', $property->description ,['id'=> 'id-description', 'class'=> 'mceEditor description', 'placeholder'=>'Please enter...', 'maxlength' => 60000])}}
                    <!--<div class="counter-display"><div class="counter-value"></div></div>-->
                </div>
            </div>
        </div>
    </div>
</div>

@if(setting('translations'))
    @if(isset($languages))
            @foreach($languages as $k => $v)
                <div class="x_panel pw-inner-tabs">
                    <div class="x_title">
                        <h2>Description ({{ $k }})</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="xpw-fields">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php
                                        $translations = $property->translations;
                                        $saved_translations = array();
                                        $translation_data = array();
                                        foreach($translations as $translation)
                                        {
                                            $saved_translations[] = $translation->language;
                                            $translation_data[$translation->language] = $translation->description;
                                        }
                                     ?>
                                    @if($property->translations->count())
                                        @if(in_array($v, $saved_translations))
                                            {{Form::textarea('description_'.$v, $translation_data[$v],['id'=> 'content', 'class'=> 'mceEditor description', 'style'=>'width:100%', 'placeholder'=>'Please enter...', 'maxlength' => 60000])}}
                                        @else
                                            {{Form::textarea('description_'.$v, '' ,['id'=> 'id-description', 'class'=> 'mceEditor description', 'placeholder'=>'Please enter...', 'maxlength' => 60000])}}
                                        @endif
                                    @else
                                        {{Form::textarea('description_'.$v, '' ,['id'=> 'id-description', 'class'=> 'mceEditor description', 'placeholder'=>'Please enter...', 'maxlength' => 60000])}}
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
    @endif
@endif


<div class="form-group sticky-buttons">
    <button type="submit" class="btn btn-large btn-primary" name="action" >Save</button>
    @if(setting('social_sharing'))
        <a class="btn btn-primary social-share" href="#" data-share="facebook" data-url="{{ $property->url }}" data-message="Take a look at this property on our website"><i class="fab fa-facebook-square"></i> Share to Facebook</a>
    @endif
    @include('backend.properties.sticky-buttons')
</div>
@csrf
{{Form::hidden('_method', 'PUT')}}
{!! Form::close() !!}

@endsection

@push('headerscripts')
<meta name="csrf-token" content="{{ csrf_token() }}">
<link href="{{url('assets/admin/build/vendors/tagEditor/jquery.tag-editor.css')}}" rel="stylesheet">
@endpush

@push('footerscripts')
<script src="{{url('assets/admin/build/js/pw-select2-ajax.js')}}"></script>
<script src="{{url('assets/admin/build/js/page-detail.js')}}"></script>
<script src="{{url('assets/admin/build/vendors/tagEditor/jquery.caret.min.js')}}"></script>
<script src="{{url('assets/admin/build/vendors/tagEditor/jquery.tag-editor.min.js')}}"></script>
@endpush
