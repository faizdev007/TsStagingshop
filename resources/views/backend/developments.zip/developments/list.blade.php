@extends('backend.layouts.master')

@section('admin-content')
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel pw">
            <div class="x_title">
                <h2>Developments</h2>
                <ul class="nav navbar-right panel_toolbox">
                    <li class="top-button"><a href="{{admin_url('properties/create')}}" class="btn btn-small btn-primary">Create Development</a></li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="table-responsive pw-table">
                    @if(count($developments))
                        <table class="table table-striped jambo_table bulk_action table-bordered-">
                            <thead>
                            <tr>
                                <th>Title</th>
                                <th>Developer</th>
                                <th>Status</th>
                                <th>Completion Date</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                                @foreach($developments as $development)
                                    @if($development->development)
                                        <tr>
                                            <td>{{ $development->development->development_title }}</td>
                                            <td>{{ $development->development->development_developer }}</td>
                                            <td>{{ $development->development->development_status }}</td>
                                            <td>{{ date("jS F Y", strtotime($development->development->completion_date)) }}</td>
                                            <td>
                                                <a href="{{admin_url('properties/'.$development->id.'/edit')}}" class="btn btn-small btn-primary">Edit</a>
                                                @if($development->status == 0)
                                                    | <a href="{{ url($development->url) }}" target="_blank" class="btn btn-small btn-info">View</a>
                                                @endif
                                            </td>

                                        </tr>
                                    @endif
                                @endforeach
                            </tbody>
                        </table>
                    @else

                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
